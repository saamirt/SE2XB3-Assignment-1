package sort;

/**
 * The Merge class sorts an array of Product types or other Comparable types
 * using merge sort algorithms. Note that the general sorting algorithm concept
 * was learned from the Algorithms textbook
 *
 * @author Syed Aamir Tahir
 * @version 1.0
 * @since 2019-02-24
 */
public class Merge {

	/**
	 * Compares two Comparable types to see if one is less than the other
	 * 
	 * @param t    - Comparable type to be used in the comparison
	 * @param that - Comparable type to be used in the comparison
	 * @return boolean for whether t is less than that
	 */
	private static boolean less(Comparable t, Comparable that) {
		// uses the compareTo method to determine their sorted order
		return t.compareTo(that) < 0;
	}

	/**
	 * merges two Comparable arrays
	 * 
	 * @param x    - the input array containing Product types that will be merged
	 * @param sec  - the second input array containing Product types that will be
	 *             merged
	 * @param low  - the lower limit of the array
	 * @param mid  - the midpoint of the array
	 * @param high - the higher limit of the array
	 */
	private static void merge(Comparable[] x, Comparable[] sec, int low, int mid, int high) {
		// iterate through from low to high
		for (int i = low; i <= high; i++) {
			// copy array to secondary array
			sec[i] = x[i];
		}

		// initialize variable at low
		int i = low;
		// initialize variable at middle + 1
		int j = mid + 1;
		// increment through array length and merge arrays appropriately in sorted order
		for (int k = low; k <= high; k++) {
			if (i > mid) {
				x[k] = sec[j++];
			} else if (j > high) {
				x[k] = sec[i++];
			} else if (less(sec[j], sec[i])) {
				x[k] = sec[j++];
			} else {
				x[k] = sec[i++];
			}
		}
	}

	/**
	 * Recursive implementation of the merge sorting algorithm
	 * 
	 * @param x    - the input array containing Product types that will be sorted
	 * @param sec  - the second input array containing Product types that will be
	 *             sorted
	 * @param low  - the lower limit of the array
	 * @param high - the higher limit of the array
	 */
	private static void sort(Comparable[] x, Comparable[] sec, int low, int high) {
		// immediately end if high is less than or equal to low
		if (high <= low)
			return;
		// find the midpoint of the array
		int mid = low + (high - low) / 2;
		// sort each half
		sort(x, sec, low, mid);
		sort(x, sec, mid + 1, high);
		// merge each array
		merge(x, sec, low, mid, high);
	}

	/**
	 * top-down merge sort using Comparable
	 * 
	 * @param x - the input array containing products that need to be sorted.
	 * @param n - the size of the input array
	 */
	public static void sortMergeTD(Comparable[] x, int n) {
		// create secondary Comparable array
		Comparable[] sec = new Comparable[n];
		// call recursive sort method
		sort(x, sec, 0, n - 1);
	}

	/**
	 * bottom-up merge sort using Comparable
	 * 
	 * @param x - the input array containing products that need to be sorted.
	 * @param n - the size of the input array
	 */
	public static void sortMergeBU(Comparable[] x, int n) {
		// create secondary Comparable array
		Comparable[] sec = new Comparable[n];
		// iterate through array length
		for (int len = 1; len < n; len *= 2) {
			// iterate through rest array from 0 till n - len while incrementing by 2*len
			for (int low = 0; low < n - len; low += len + len) {
				// store the middle
				int mid = low + len - 1;
				// find the high index
				int high = Math.min(low + len + len - 1, n - 1);
				// merge the arrays
				merge(x, sec, low, mid, high);
			}
		}
	}
}
