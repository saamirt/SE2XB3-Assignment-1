package sort;

/**
 * The Product class represents a store product with an id and sales figure. The
 * class implements the Comparable interface.
 *
 * @author Syed Aamir Tahir
 * @version 1.0
 * @since 2019-02-24
 */
public class Product implements Comparable<Product> {
	// variable for product id
	private String id;
	// variable for product sales
	private int sales;

	/**
	 * Creates a new product
	 * 
	 * @param prodID - ID String of the product.
	 * @param sales  - integer for sales amount for the product
	 */
	public Product(String prodID, int sales) {
		// sets values for id and sales from constructor arguments
		this.id = new String(prodID);
		this.sales = sales;
	}

	/**
	 * Accessor for sales amount
	 * 
	 * @return integer for sales amount for the product
	 */
	public int getSales() {
		return sales;
	}

	/**
	 * Sets the sales amount for the product
	 * 
	 * @param sales - integer for new sales amount for the product
	 */
	public void setSales(int sales) {
		this.sales = sales;
	}

	/**
	 * Accessor for product ID
	 * 
	 * @return String for product ID
	 */
	public String getId() {
		return id;
	}

	/**
	 * Displays object as string
	 * 
	 * @return String with product ID and product sales
	 */
	public String toString() {
		return id + ", " + sales;
	}

	@Override
	/**
	 * Compares two products to order when sorting
	 * 
	 * @param j - product to compare to
	 * @return integer 1 if object is greater than the parameter, 0 if the object is
	 *         equal to the parameter, and -1 if the object is less than the
	 *         parameter
	 */
	public int compareTo(Product j) {
		// returns 1 if this object's sales are greater, -1 if they are lower, and
		// returns the a comparison of the ids if they are equal
		return (this.sales > j.getSales()) ? 1 : (this.sales < j.getSales()) ? -1 : this.id.compareTo(j.getId());
	}
}
