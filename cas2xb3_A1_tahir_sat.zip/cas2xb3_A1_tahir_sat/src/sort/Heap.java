package sort;

/**
 * The Heap class sorts an array of Product types or other Comparable types
 * using heap sort algorithms. Note that the general sorting algorithm concept
 * was learned from the Algorithms textbook
 *
 * @author Syed Aamir Tahir
 * @version 1.0
 * @since 2019-02-24
 */
public class Heap {

	/**
	 * Compares two Comparable types to see if one is less than the other
	 * 
	 * @param t    - Comparable type to be used in the comparison
	 * @param that - Comparable type to be used in the comparison
	 * @return boolean for whether t is less than that
	 */
	private static boolean less(Comparable t, Comparable that) {
		// uses the compareTo method to determine their sorted order
		return t.compareTo(that) < 0;
	}

	/**
	 * appropriately sinks element until it is in the correct place
	 * 
	 * @param x - Comparable type array that is being sorted
	 * @param i - node of tree
	 * @param n - size of heap
	 */
	private static void sink(Comparable[] x, int i, int n) {
		// loops while i/2 is less than or equal to the size of the heap
		while (i << 1 <= n) {
			// stores value of i/2
			int j = i << 1;
			// increments j if it is less than size of heap and element before j is less
			// than j
			if (j < n && less(x[j - 1], x[j]))
				j++;
			// break loop if element before i is greater than or equal to the element before
			// j
			if (!less(x[i - 1], x[j - 1]))
				break;
			// swaps x[i-1] and x[j-1]
			Comparable tmp = x[i - 1];
			x[i - 1] = x[j - 1];
			x[j - 1] = tmp;
			// sets i to j
			i = j;
		}
	}

	/**
	 * heap sort using Comparable
	 * 
	 * @param x - the input array containing jobs that need to be sorted.
	 * @param n - the size of the input array
	 */
	public static void sortHeap(Comparable[] x, int n) {
		// iterates through the array from n/2 till i >= 1
		for (int i = n >> 1; i >= 1; i--)
			// calls sink method
			sink(x, i, n);
		// while length is greather than 1
		while (n > 1) {
			// swaps x[0] and x[n]
			Comparable tmp = x[0];
			x[0] = x[--n];
			x[n] = tmp;
			// calls sink method
			sink(x, 1, n);
		}
	}
}
