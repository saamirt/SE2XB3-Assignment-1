package sort;

/**
 * The Quick class sorts an array of Product types or other Comparable types
 * using quick sort algorithms. Note that the general sorting algorithm concept
 * was learned from the Algorithms textbook
 *
 * @author Syed Aamir Tahir
 * @version 1.0
 * @since 2019-02-24
 */
public class Quick {

	/**
	 * Compares two Comparable types to see if one is less than the other
	 * 
	 * @param t    - Comparable type to be used in the comparison
	 * @param that - Comparable type to be used in the comparison
	 * @return boolean for whether t is less than that
	 */
	private static boolean less(Comparable t, Comparable that) {
		// uses the compareTo method to determine their sorted order
		return t.compareTo(that) < 0;
	}

	/**
	 * Partitioning an array for quick sort
	 * 
	 * @param x    - the input array containing Product types that need to be
	 *             sorted.
	 * @param low  - the lower limit of the array
	 * @param high - the higher limit of the array
	 * @return int for partitioning index
	 */
	private static int partition(Product[] x, int low, int high) {
		// sets variables initialized at the low and high positions
		int i = low;
		int j = high;

		// initializes the pivot at the lowest element in the range
		Product pivot = x[low];

		// loop runs till elements are appropriately sorted to be below or above the
		// pivot
		while (true) {
			// increments i until it is equal to the pivot or reaches the top of the range
			while (less(x[++i], pivot))
				if (i == high)
					break;
			// decrements j until it is equal to the pivot
			while (less(pivot, x[j]))
				j--;
			// ensures that i is less than j
			if (i >= j)
				break;
			// swaps x[i] and x[j]
			Product tmp = x[i];
			x[i] = x[j];
			x[j] = tmp;
		}
		// swaps x[low] and x[j]
		Product tmp = x[low];
		x[low] = x[j];
		x[j] = tmp;
		return j;
	}

	/**
	 * Quick sort for Product types using a basic quick sort algorithm.
	 * 
	 * @param x    - the input array containing Product types that need to be
	 *             sorted.
	 * @param low  - the lower limit of where the array must be sorted
	 * @param high - the higher limit of where the array must be sorted
	 */
	private static void sortBasic(Product[] x, int low, int high) {
		// immediately ends if high is less than or equal to low
		if (high <= low)
			return;
		// initializes partition index
		int p = partition(x, low, high);
		// sorts both sides of the partition index recursively
		sortBasic(x, low, p - 1);
		sortBasic(x, p + 1, high);
	}

	/**
	 * Quick sort for Comparable types using Median-of-three partitioning.
	 * 
	 * @param x    - the input array containing Comparable types that need to be
	 *             sorted.
	 * @param low  - the lower limit of where the array must be sorted
	 * @param high - the higher limit of where the array must be sorted
	 */
	private static void sortThree(Comparable[] x, int low, int high) {
		// immediately ends if high is less than or equal to low
		if (high <= low)
			return;
		// initializes partition indices at low and high
		int pl = low;
		int pg = high;
		// sets the pivot at the lowest element
		Comparable pivot = x[low];

		// initialize variable 1 above the lower range
		int i = low + 1;
		// loop runs until i is less than or equal to pg
		while (i <= pg) {
			int comparsion = x[i].compareTo(pivot);
			// if x[i] is less than pivot, swap x[pl] and x[i] an increment both
			if (comparsion < 0) {
				Comparable tmp = x[pl];
				x[pl++] = x[i];
				x[i++] = tmp;
				// if x[i] is greater than pivot, swap x[i] and x[pg] an decrement pg
			} else if (comparsion > 0) {
				Comparable tmp = x[i];
				x[i] = x[pg];
				x[pg--] = tmp;
				// if x[i] is equal to the pivot, increment i
			} else
				i++;
		}
		// sort each side of the partition indices
		sortThree(x, low, pl - 1);
		sortThree(x, pg + 1, high);
	}

	/**
	 * basic quick sort
	 * 
	 * @param x - the input array containing products that need to be sorted.
	 */
	public static void sortBasicQuick(Product[] x) {
		// calls recursive sorting function
		sortBasic(x, 0, x.length - 1);
	}

	/**
	 * three partition quick sort using Comparable
	 * 
	 * @param x - the input array containing products that need to be sorted.
	 * @param n - the size of the input array
	 */
	public static void sortThreePartition(Comparable[] x, int n) {
		// calls recursive sorting function
		sortThree(x, 0, n - 1);
	}

}
