package sort;

/**
 * The Stopwatch class is used to find time elapsed over running some code
 *
 * @author Syed Aamir Tahir
 * @version 1.0
 * @since 2019-02-24
 */
public class Stopwatch {
	private final long start;

	/**
	 * Creates new stopwatch
	 */
	public Stopwatch() {
		start = System.nanoTime();
	}

	/**
	 * Finds time elapsed since object was created
	 * 
	 * @return double with number of nanoseconds since creation of object
	 */
	public double elapsedTime() {
		// gets elapsed time in nanoseconds
		long now = System.nanoTime();
		return (now - start);
	}
}
