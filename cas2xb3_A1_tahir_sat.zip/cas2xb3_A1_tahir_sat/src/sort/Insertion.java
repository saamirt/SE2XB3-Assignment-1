package sort;

/**
 * The Insertion class sorts an array of Product types or other Comparable types
 * using insertion sort algorithms.Note that the general sorting algorithm
 * concept was learned from the Algorithms textbook
 *
 * @author Syed Aamir Tahir
 * @version 1.0
 * @since 2019-02-24
 */
public class Insertion {

	/**
	 * Compares two Comparable types to see which order they must be in
	 * 
	 * @param a - Comparable type to be used in the comparison
	 * @param b - Comparable type to be used in the comparison
	 * @return 1 if a's sales are greater than b, -1 if a's sales are less than b.
	 *         This is done using lexicographic comparison of their IDs if their
	 *         sales are equal.
	 */
	private static int compProducts(Product a, Product b) {
		// initializes variables for the sales of each product
		int aSales = a.getSales();
		int bSales = b.getSales();
		// compares sales
		if (aSales > bSales)
			// returns 1 if a has greater sales
			return 1;
		else if (aSales < bSales)
			// returns -1 if a has lesser sales
			return -1;
		// initializes variables for the ids of each product
		String aId = a.getId();
		String bId = b.getId();
		// runs through the characters of each id to compare their values
		for (int i = 0; i < Math.min(aId.length(), bId.length()); i++) {
			// if the character from the first product id is greater, returns 1
			if ((int) aId.charAt(i) > (int) bId.charAt(i))
				return 1;
			// if the character from the second product id is greater, returns 1
			else if ((int) aId.charAt(i) < (int) bId.charAt(i))
				return -1;
		}
		// if the strings are identical up to the point at which the smallest string
		// ends, compare their lengths (as is normally done by the String compareTo
		// method)
		return aId.length() > bId.length() ? 1 : -1;
	}

	/**
	 * regular insertion sort
	 * 
	 * @param x - the input array containing products that need to be sorted.
	 */
	public static void sortInsert(Product[] x) {
		// stores length of array
		int n = x.length;

		int i;
		// iterates through elements of array
		for (int marker = 1; marker < n; marker++) {
			// stores current element
			Product elem = x[marker];
			// stores index of element before current element
			i = marker - 1;

			// loops until i is less than 0 or x[i] is not greater than the current element
			while (i >= 0 && compProducts(x[i], elem) > 0) {
				// sets element after i to element at i
				x[i + 1] = x[i];
				// decrements i
				i--;
			}
			// sets element after i to the current element value
			x[i + 1] = elem;
		}
	}

	/**
	 * insertion sort using Comparable
	 * 
	 * @param x - the input array containing products that need to be sorted.
	 * @param n - the size of the input array
	 */
	public static void sortComparable(Comparable[] x, int n) {
		int i;
		// iterates through elements of array
		for (int marker = 1; marker < n; marker++) {
			// stores current element
			Comparable elem = x[marker];
			// stores index of element before current element
			i = marker - 1;

			// loops until i is less than 0 or x[i] is not greater than the current element
			while (i >= 0 && x[i].compareTo(elem) > 0) {
				// sets element after i to element at i
				x[i + 1] = x[i];
				// decrements i
				i--;
			}
			// sets element after i to the current element value
			x[i + 1] = elem;
		}
	}

	/**
	 * Performs binary search to find where an element is located or where it would
	 * be placed.
	 * 
	 * @param x    - the input array containing Comparable types that need to be
	 *             sorted.
	 * @param low  - the lower limit of where the array must be searched
	 * @param high - the higher limit of where the array must be searched
	 * @param elem - the Comparable item that is being searched for
	 * @return index of where element must be placed
	 */
	private static int binarySearch(Comparable[] x, int low, int high, Comparable elem) {
		// if low is equal to high, check if target element belongs at the bottom or top
		if (low == high) {
			// if low element is greater than the target element, return the low index
			if (x[low].compareTo(elem) > -1)
				return low;
			// otherwise return 1 above the low index
			else
				return low + 1;
			// immediately return low if low is greater than high
		} else if (low > high)
			return low;

		// find midpoint index
		int mid = (low + high) / 2;
		// store comparison of middle element to target element
		int comparison = x[mid].compareTo(elem);
		// if middle element is greater than target
		if (comparison < 0)
			// search in the range above the middle element
			return binarySearch(x, mid + 1, high, elem);
		// if it is lower
		else if (comparison > 0)
			// search in the range below the middle element
			return binarySearch(x, low, mid - 1, elem);
		else
			// otherwise, it must be the element itself
			return mid;
	}

	/**
	 * optimized insertion sort
	 * 
	 * @param x - the input array containing products that need to be sorted.
	 * @param n - the size of the input array
	 */
	public static void sortBinary(Comparable[] x, int n) {
		// iterate through the array length
		for (int marker = 1; marker < n; marker++) {
			// store current element
			Comparable elem = x[marker];
			// find where current element should be placed in the sorted portion of the
			// array
			int index = Math.abs(binarySearch(x, 0, marker, elem));

			// place the current element in its proper place
			System.arraycopy(x, index, x, index + 1, marker - index);
			x[index] = elem;
		}
	}
}
