/**
 * 
 */
package sort;

import static org.junit.Assert.assertTrue;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The SortTest class is used to test the Insertion, Merge, Quick, and Heap
 * classes. The class uses junit testing to ensure that the sorting algorithms
 * work correctly. Note that the general sorting algorithm concept was learned
 * from the Algorithms textbook
 *
 * @author Syed Aamir Tahir
 * @version 1.0
 * @since 2019-02-24
 */
public class SortTest {

	Product[][] data;

	/**
	 * Sets up data before each test
	 * 
	 * @throws java.lang.Exception Setup error
	 */
	@Before
	public void setUp() throws Exception {
		// reads input file
		BufferedReader r;
		// stores number of lines to read
		int numLines = 7;
		try {
			// reads file using BufferredReader and FileReader
			r = new BufferedReader(new FileReader("data\\a1_in.txt"));
			// initializes size of data array
			data = new Product[numLines][];
			// iterates through lines of input file
			for (int i = 0; i < numLines; i++) {
				// stores line string
				String line = r.readLine();
				// finds each product using regex
				String[] prodStrings = line.split("\\{|(\\}\\s*,\\s*\\{)|\\}");
				// initializes each set of data based on the size of products in the line
				data[i] = new Product[prodStrings.length - 1];
				// initializes values for product array by parsing through the product strings
				for (int j = 1; j < prodStrings.length; j++) {
					// seperates values by comma
					String[] prodData = prodStrings[j].split(",");
					// creates product from data
					data[i][j - 1] = new Product(prodData[0], Integer.parseInt(prodData[1]));
				}
			}
			// closes reader
			r.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * tears down the data from each test's setup
	 * 
	 * @throws java.lang.Exception Teardown error
	 */
	@After
	public void tearDown() throws Exception {
	}

	private static boolean less(Comparable t, Comparable that) {
		return t.compareTo(that) < 0;
	}

	private static boolean isSorted(Comparable[] a) {
		// iterates through array and checks that its in order
		for (int i = 1; i < a.length; i++) {
			if (less(a[i], a[i - 1]))
				return false;
		}
		return true;
	}

	@Test
	public void testMergeTD() {
		// running the data array
		for (int i = 0; i < data.length; i++) {
			// starting the timer
			Stopwatch timer = new Stopwatch();
			// sorting the array
			Merge.sortMergeTD(data[i], data[i].length);
			// storing the elapsed time
			double elapsed = timer.elapsedTime();
			// printing the time elapsed
			System.out.println("testMergeTD - " + i + ": " + elapsed);
			// checking that the array was sorted
			assertTrue(isSorted(data[i]));
		}
	}

	@Test
	public void testMergeBU() {
		// running the data array
		for (int i = 0; i < data.length; i++) {
			// starting the timer
			Stopwatch timer = new Stopwatch();
			// sorting the array
			Merge.sortMergeBU(data[i], data[i].length);
			// storing the elapsed time
			double elapsed = timer.elapsedTime();
			// printing the time elapsed
			System.out.println("testMergeBU - " + i + ": " + elapsed);
			// checking that the array was sorted
			assertTrue(isSorted(data[i]));
		}
	}

	@Test
	public void testSortInsert() {
		// running the data array
		for (int i = 0; i < data.length; i++) {
			// starting the timer
			Stopwatch timer = new Stopwatch();
			// sorting the array
			Insertion.sortInsert(data[i]);
			// storing the elapsed time
			double elapsed = timer.elapsedTime();
			// printing the time elapsed
			System.out.println("testSortInsert - " + i + ": " + elapsed);
			// checking that the array was sorted
			assertTrue(isSorted(data[i]));
		}
	}

	@Test
	public void testInsertComparable() {
		// running the data array
		for (int i = 0; i < data.length; i++) {
			// starting the timer
			Stopwatch timer = new Stopwatch();
			// sorting the array
			Insertion.sortComparable(data[i], data[i].length);
			// storing the elapsed time
			double elapsed = timer.elapsedTime();
			// printing the time elapsed
			System.out.println("testInsertComparable - " + i + ": " + elapsed);
			// checking that the array was sorted
			assertTrue(isSorted(data[i]));
		}
	}

	@Test
	public void testInsertBinary() {
		// running the data array
		for (int i = 0; i < data.length; i++) {
			// starting the timer
			Stopwatch timer = new Stopwatch();
			// sorting the array
			Insertion.sortBinary(data[i], data[i].length);
			// storing the elapsed time
			double elapsed = timer.elapsedTime();
			// printing the time elapsed
			System.out.println("testInsertBinary - " + i + ": " + elapsed);
			// checking that the array was sorted
			assertTrue(isSorted(data[i]));
		}
	}

	@Test
	public void testBasicQuick() {
		// running the data array
		for (int i = 0; i < data.length; i++) {
			// starting the timer
			Stopwatch timer = new Stopwatch();
			// sorting the array
			Quick.sortBasicQuick(data[i]);
			// storing the elapsed time
			double elapsed = timer.elapsedTime();
			// printing the time elapsed
			System.out.println("testBasicQuick - " + i + ": " + elapsed);
			// checking that the array was sorted
			assertTrue(isSorted(data[i]));
		}
	}

	@Test
	public void testThreePartition() {
		// running the data array
		for (int i = 0; i < data.length; i++) {
			// starting the timer
			Stopwatch timer = new Stopwatch();
			// sorting the array
			Quick.sortThreePartition(data[i], data[i].length);
			// storing the elapsed time
			double elapsed = timer.elapsedTime();
			// printing the time elapsed
			System.out.println("testThreePartition - " + i + ": " + elapsed);
			// checking that the array was sorted
			assertTrue(isSorted(data[i]));
		}
	}

	@Test
	public void testHeap() {
		// running the data array
		for (int i = 0; i < data.length; i++) {
			// starting the timer
			Stopwatch timer = new Stopwatch();
			// sorting the array
			Heap.sortHeap(data[i], data[i].length);
			// storing the elapsed time
			double elapsed = timer.elapsedTime();
			// printing the time elapsed
			System.out.println("testHeap - " + i + ": " + elapsed);
			// checking that the array was sorted
			assertTrue(isSorted(data[i]));
		}
	}

}
