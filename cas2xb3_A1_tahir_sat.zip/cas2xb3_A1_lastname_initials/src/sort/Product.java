package sort;

public class Product implements Comparable<Product>{
	@Override
	public int compareTo(Product j)
	{
		//TODO
		return 0;
	}
}
