package cas.XB3.lab4.wt;

public class Stopwatch {
	private final long start;
	
	public Stopwatch() {
		start = System.currentTimeMillis();
	}
	
	public double elapsedTime() {
		long now = System.currentTimeMillis();
		return (now - start)/1000.00;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n = Integer.parseInt(args[0]);
		Stopwatch timer1 = new Stopwatch();
		double sum1 = 0.0;
		for (int i = 1; i <= n; i++) {
			sum1 += Math.sqrt(i);
		}
		double time1 = timer1.elapsedTime();
		System.out.printf("%e (%.2f seconds)\n", sum1, time1);
	}

}
