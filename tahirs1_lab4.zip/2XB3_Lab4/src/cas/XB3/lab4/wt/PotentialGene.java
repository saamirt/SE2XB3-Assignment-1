package cas.XB3.lab4.wt;

public class PotentialGene {
	public static boolean isPotentialGene(String dna) {
		String mid = dna.substring(3, dna.length() - 3);
		if (
				dna.length() % 3 == 0 &&
				dna.startsWith("ATG") &&
				(dna.endsWith("TAA") || dna.endsWith("TAG") || dna.endsWith("TGA")) &&
				!mid.contains("TAA") &&
				!mid.contains("TAG") &&
				!mid.contains("TGA")) {
			return true;
		}
		return false;
	}

	public static void main(String[] args) {
		String dna = args[0];
		System.out.println(isPotentialGene(dna));
	}
}
